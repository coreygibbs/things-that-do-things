// Startup Express App
var express = require('express');
var app = express();
var http = require('http').Server(app);
http.listen(process.env.VCAP_APP_PORT || 3000);
//respond with "hello world" when a GET request is made to the homepage
app.get('/', function(req, res) {
  res.send('Hello World\nI am your friendly cloudfoundry NodeJs app.\n\ncheers!');
});

app.get('/crashme/', function(req, res) {

  var h = 0;
  if(h < 1000) {
    setTimeout(loopme, 500);
  }
  
  //res.send('id ' + req.params.id);    
});

function loopme(params) {
  {
      var i = 0;
      if(i < 5000) {
        throw new Error('my silly error');
      i++;
    }
  }
  
}